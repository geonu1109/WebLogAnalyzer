#ifndef __UTILITY_H__
#define __UTILITY_H__
#include <stdio.h>

FILE *openFile(const char * strFilePath, const char * strFileMode);

#endif