#ifndef __CONFIG_H__
#define __CONFIG_H__

void loadConfig(void);

#endif