#ifndef __DATA_H__
#define __DATA_H__

void showMenu(void);

#endif